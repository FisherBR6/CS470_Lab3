#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//process struct
typedef struct process {
    int processID;
    int arriveTime;
    int burstTime;
    int waitTime;
    int turnTime;
    int procCompleted;
    int hasBegun;
} Process;

//swap the two passed processes
void swap(Process* a, Process* b) {
    Process temp = *a;
    *a = *b;
    *b = temp;
}

//partition a process array for quicksorting
int partitionSJF(Process arr[], int low, int high) {
    int p = arr[low].burstTime;
    int i = low;
    int j = high;

    while (i < j) {
        while (arr[i].burstTime <= p && i <= high - 1) {
            i++;
        }
        while (arr[j].burstTime > p && j >= low + 1) {
            j--;
        }
        if (i < j) {
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[low], &arr[j]);
    return j;
}

//quickSort function sorts processes based on burst time
void quickSortSJF(Process arr[], int low, int high) {
    if (low < high) {
        int pi = partitionSJF(arr, low, high);
        quickSortSJF(arr, low, pi - 1);
        quickSortSJF(arr, pi + 1, high);
    }
}

//partition a process array for quicksorting
int partitionRR(Process arr[], int low, int high) {
    int p = arr[low].arriveTime;
    int i = low;
    int j = high;

    while (i < j) {
        while (arr[i].arriveTime <= p && i <= high - 1) {
            i++;
        }
        while (arr[j].arriveTime > p && j >= low + 1) {
            j--;
        }
        if (i < j) {
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[low], &arr[j]);
    return j;
}

//quickSort function sorts processes based on arrive time
void quickSortRR(Process arr[], int low, int high) {
    if (low < high) {
        int pi = partitionRR(arr, low, high);
        quickSortRR(arr, low, pi - 1);
        quickSortRR(arr, pi + 1, high);
    }
}

//sjf function simulates Shortest Job First CPU process management
void sjf(Process arr[], int numProcs){
    for (int i = 0; i < numProcs; ++i) {
        if(arr[i].procCompleted != 1) {
            printf("%s%d%s", "Process with ID ", arr[i].processID, " is being executed\n");
            sleep(arr[i].burstTime);
            for (int j = 0; j < i; ++j) {
                arr[i].waitTime+= arr[j].burstTime;
            }
            arr[i].procCompleted = 1;
            printf("%s%d%s", "Process with ID ", arr[i].processID, " has been completed\n");
            printf("%s%d%c", "---This process arrived at time ", arr[i].arriveTime, '\n');
            printf("%s%d%c", "---This process's wait time was ", arr[i].waitTime, '\n');
        }
    }
}

//rr function simulates Round Robin CPU process management
void rr(Process arr[], int numProcs){
    int timeSlice = 1;
    int allProcComplete = 0;

    while(1){
        allProcComplete = 1;
        for(int i = 0; i < numProcs;i++){
            for (int j = 0; j < numProcs; ++j) {
                if(!arr[j].procCompleted && arr[j].hasBegun){
                    arr[j].turnTime+=1;
                }
            }
            if(arr[i].procCompleted != 1) {
                arr[i].hasBegun = 1;
                allProcComplete = 0;
                if (arr[i].burstTime > 0) {
                    printf("%s%d%s", "Process with ID ", arr[i].processID, " is being executed\n");
                    sleep(timeSlice);
                    arr[i].burstTime -= timeSlice;
                    //arr[i].turnTime+=1;
                } else {
                    arr[i].procCompleted = 1;
                    printf("%s%d%s", "Process with ID ", arr[i].processID, " has been completed\n");
                    printf("%s%d%c", "---This process arrived at time ", arr[i].arriveTime, '\n');
                    printf("%s%d%c", "---This process's turnaround time was ", arr[i].turnTime, '\n');
                }
            }
        }
        if(allProcComplete){
            break;
        }
    }
}

int main() {
    //instantiate an integer variable to store the number of processes to be executed
    int numProc;

    //seed the random number generator
    srand(time(NULL));

    //prompt the user for the number of processes
    printf("Enter the number of processes to be managed: ");
    scanf("%d", &numProc);

    //declare an array of processes
    Process procArray[numProc];

    //initialize process IDs and random burst/arrival times
    for (int i = 0; i < numProc; ++i) {
        procArray[i].processID = i + 1;  // Assign a unique process ID
        procArray[i].arriveTime = rand() % 10+1;
        procArray[i].burstTime = rand() % 10 + 1;
        procArray[i].waitTime = 0;
        procArray[i].turnTime = 0;
        procArray[i].procCompleted = 0;
    }

    //make a copy of the array
    Process procArray2[numProc];
    for (int i = 0; i < numProc; ++i) {
        procArray2[i].processID = procArray[i].processID + numProc;
        procArray2[i].arriveTime = procArray[i].arriveTime + numProc;
        procArray2[i].burstTime = rand() % 10 + 1;
        procArray2[i].waitTime = 0;
        procArray2[i].turnTime = 0;
        procArray2[i].procCompleted = 0;
    }

    //display the array before sorting for SJF

    //sort the processes based on burst time for SJF
    quickSortSJF(procArray, 0, numProc - 1);

    //sort the processes based on arrival time for RR
    quickSortRR(procArray2, 0, numProc - 1);

    //display the array after sorting for SJF
    printf("\nProcesses for Shortest Job First sorted by burst time:\n");
    for (int i = 0; i < numProc; ++i) {
        printf("Process ID: %d, Arrival Time: %d, Burst Time: %d\n",
               procArray[i].processID, procArray[i].arriveTime, procArray[i].burstTime);
    }

    //display the second array after sorting for RR
    printf("\nProcesses for Round Robin sorted by arrival time:\n");
    for (int i = 0; i < numProc; ++i) {
        printf("Process ID: %d, Arrival Time: %d, Burst Time: %d\n",
               procArray2[i].processID, procArray2[i].arriveTime, procArray2[i].burstTime);
    }

    //perform SJF scheduling
    printf("%s", "\nPerforming Shortest Job First:\n");
    sjf(procArray, numProc);

    //perform RR scheduling
    printf("%s", "\nPerforming Round Robin:\n");
    rr(procArray2, numProc);

    return 0;
}
