#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//process struct
typedef struct process {
    int processID;
    int arriveTime;
    int burstTime;
    int waitTime;
    int turnTime;
    int procCompleted;
} Process;

//swap the two passed processes
void swap(Process* a, Process* b) {
    Process temp = *a;
    *a = *b;
    *b = temp;
}

//partition a process array for quicksorting
int partition(Process arr[], int low, int high) {
    int p = arr[low].burstTime;
    int i = low;
    int j = high;

    while (i < j) {
        while (arr[i].burstTime <= p && i <= high - 1) {
            i++;
        }
        while (arr[j].burstTime > p && j >= low + 1) {
            j--;
        }
        if (i < j) {
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[low], &arr[j]);
    return j;
}

//quickSort function sorts processes based on burst time
void quickSort(Process arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

//sjf function simulates Shortest Job First CPU process management
void sjf(Process arr[], int numProcs){
    for (int i = 0; i < numProcs; ++i) {
        if(arr[i].procCompleted != 1) {
            printf("%s%d%s", "Process with ID ", arr[i].processID, " is being executed\n");
            sleep(arr[i].burstTime);
            arr[i].burstTime = -1;
            arr[i].procCompleted = 1;
            printf("%s%d%s", "Process with ID ", arr[i].processID, " has been completed\n");
        }
    }
}

//rr function simulates Round Robin CPU process management
void rr(Process arr[], int numProcs){
    int timeSlice = 1;
    int allProcComplete = 0;
    while(1){
        allProcComplete = 1;
        for(int i = 0; i < numProcs;i++){
            if(arr[i].procCompleted != 1) {
                allProcComplete = 0;
                if (arr[i].burstTime > 0) {
                    printf("%s%d%s", "Process with ID ", arr[i].processID, " is being executed\n");
                    sleep(timeSlice);
                    arr[i].burstTime -= timeSlice;
                } else {
                    printf("%s%d%s", "Process with ID ", arr[i].processID, " has been completed\n");
                    arr[i].procCompleted = 1;
                }
            }
        }
        if(allProcComplete){
            break;
        }
    }
}

int main() {
    //instantiate an integer variable to store the number of processes to be executed
    int numProc;

    //seed the random number generator
    srand(time(NULL));

    //prompt the user for the number of processes
    printf("Enter the number of processes to be managed: ");
    scanf("%d", &numProc);

    //declare an array of processes
    Process procArray[numProc];

    //initialize process IDs and random burst/arrival times
    for (int i = 0; i < numProc; ++i) {
        procArray[i].processID = i + 1;  // Assign a unique process ID
        procArray[i].arriveTime = rand() % 10;
        procArray[i].burstTime = rand() % 10 + 1;
        procArray[i].waitTime = 0;
        procArray[i].turnTime = 0;
        procArray[i].procCompleted = 0;
    }

    //make a copy of the array
    Process procArray2[numProc];
    for (int i = 0; i < numProc; ++i) {
        procArray2[i].processID = procArray[i].processID;
        procArray2[i].arriveTime = procArray[i].processID;
        procArray2[i].burstTime = procArray[i].processID;
        procArray2[i].waitTime = 0;
        procArray2[i].turnTime = 0;
        procArray2[i].procCompleted = 0;
    }

    //display the array before sorting for SJF
    printf("Processes before sorting:\n");
    for (int i = 0; i < numProc; ++i) {
        printf("Process ID: %d, Arrival Time: %d, Burst Time: %d\n",
               procArray[i].processID, procArray[i].arriveTime, procArray[i].burstTime);
    }

    //sort the processes based on burst time for SJF
    quickSort(procArray, 0, numProc - 1);

    //display the array after sorting for SJF
    printf("\nProcesses after sorting by burst time:\n");
    for (int i = 0; i < numProc; ++i) {
        printf("Process ID: %d, Arrival Time: %d, Burst Time: %d\n",
               procArray[i].processID, procArray[i].arriveTime, procArray[i].burstTime);
    }

    //perform SJF scheduling
    printf("%s", "\nPerforming Shortest Job First:\n");
    sjf(procArray, numProc);

    //perform RR scheduling
    printf("%s", "\nPerforming Round Robin:\n");
    rr(procArray2, numProc);

    return 0;
}
